/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/**/*.{html,js}"],
  theme: {
    extend: {
      backgroundImage:{
        offerBannner: "url(../dist/img/what-we-offer-bg-scaled.jpg)",
        movingbg: "url(../dist/img/bg-3.svg)",
      },
      colors:{
        primary: "#6a103f",
        secondary: "#f5f5f5",
        light: "#ffffff",
        midprimary: "#c11770",
      }
    },
  },
  plugins: [],
}

